# file_missing.py
# Python 3.7.6  NumPy 1.18.1
# find and deal with missing data

import numpy as np

def line_count(fn):
  ct = 0
  fin = open(fn, "r")
  for line in fin:
    ct += 1
  fin.close()
  return ct

def show_file(fn, start, end, indices=False,
 strip_nl=False):
  fin = open(fn, "r")

  # advance to start line
  ln = 1
  while ln < start:
    fin.readline()
    ln += 1

  # show remaining lines
  while ln <= end:
    line = fin.readline()
    if line == "": break  # EOF
    if strip_nl == True:
      line = line.strip()
    if indices == True:
      print("[%3d]  " % ln, end="")
    print(line)
    ln += 1
  fin.close()

def show_short_lines(fn, num_cols, delim):
  fin = open(fn, "r")
  line_num = 0
  for line in fin:
    line = line.rstrip()
    line_num += 1
    tokens = line.split(delim)
    if len(tokens) != num_cols:
      print("[%3d]:  " % line_num, end="")
      print(line)
  fin.close()  

def delete_lines(src, dest, omit_lines):
  fin = open(src, "r"); fout = open(dest, "w")
  line_num = 1
  for line in fin:
    if line_num in omit_lines:
      line_num += 1 
    else:
      fout.write(line)  # has embedded nl
      line_num += 1
  fout.close(); fin.close()

def remove_cols(src, dest, omit_cols,  delim):
  # cols is 1-based
  fin = open(src, "r")
  fout = open(dest, "w")
  for line in fin:
    s = ""  # reconstucted line
    line = line.rstrip()  # remove newline
    tokens = line.split(delim)
    for j in range(0, len(tokens)):  # j is 0-based
      if j+1 in omit_cols:  # col to delete
        continue
      elif j != len(tokens)-1:  # interior col
        s += tokens[j] + delim
      else:
        s += tokens[j]          # last col
    s += "\n"
    fout.write(s)
  fout.close(); fin.close()
  return

def main():
  # 1. examine
  fn = ".\\people_raw.txt"
  ct = line_count(fn)
  print("\nSource file has " + str(ct) + " lines")

  print("\nLines 1-17: ")
  show_file(fn, 1, 17, indices=True, strip_nl=True)

  # 2. deal with missing data
  print("\nLines with fewer or more than 6 columns:")
  show_short_lines(fn, 6, "\t")

  print("\nDeleting lines [1, 2, 9, 15]")
  src = ".\\people_raw.txt"
  dest = ".\\people_no_missing.txt"
  delete_lines(src, dest, [1, 2, 9, 15])

  # 3. remove unwanted columns
  print("\nRemoving cols [3]")
  src = ".\\people_no_missing.txt"
  dest = ".\\people_no_missing_lean.txt"
  remove_cols(src, dest, [3], "\t")

  print("\nResult file: ")
  show_file(dest, 1, 99999, indices=True, strip_nl=True)

  print("\nEnd demo")

if __name__ == "__main__":
  main()

